import { useState } from "react";
import { Car } from "./CarList";
import { error } from "console";
import axios from "axios";
interface IEditForm {
  car?: Car;
}

const EditForm = ({ car }: IEditForm) => {
  const [editedCar, setEditedCar] = useState({ ...car });
  const  update =()=>{
    axios.put(`http://localhost:5242/api/Car/${editedCar.id}`,{
    id : editedCar.id,
    brand: editedCar.brand,
    model: editedCar.model,
    doorsNumber: editedCar.doorsNumber,
    luggageCapacity: editedCar.luggageCapacity,
    engineCapacity: editedCar.engineCapacity,
    fuelType: editedCar.fuelType,
    productionDate: editedCar.productionDate,
    carFuelConsumption: editedCar.carFuelConsumption,
    bodyType: editedCar.bodyType,
      
    })
    
  }
  return (
    <>
      <h2>Edycja</h2>
      <form onSubmit={update}>
        <label htmlFor="brand">Marka</label>
        <input
          type="text"
          id="brand"
          value={editedCar.brand}
          onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
            setEditedCar((prevDetails) => ({
              ...prevDetails,
              brand: e.target.value,
            }))
          }
          name="brand"
        />
        <br />
        <label htmlFor="model">Model</label>
        <input
          type="text"
          id="model"
          value={editedCar.model}
          onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
            setEditedCar((prevDetails) => ({
              ...prevDetails,
              model: e.target.value,
            }))
          }
          name="model"
        />
        <br />
        <label htmlFor="doorsNumber">Liczba drzwi</label>
        <input
          type="number"
          id="doorsNumber"
          value={editedCar.doorsNumber}
          onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
            setEditedCar((prevDetails) => ({
              ...prevDetails,
              doorsNumber: parseInt(e.target.value),
            }))
          }
          name="doorsNumber"
        />
        <br />
        <label htmlFor="luggageCapacity">Pojemność bagażnika</label>
        <input
          type="number"
          id="luggageCapacity"
          value={editedCar.luggageCapacity}
          onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
            setEditedCar((prevDetails) => ({
              ...prevDetails,
              luggageCapacity: parseInt(e.target.value),
            }))
          }
          name="luggageCapacity"
        />
        <br />
        <label htmlFor="engineCapacity">Pojemność silnika</label>
        <input
          type="number"
          id="engineCapacity"
          value={editedCar.engineCapacity}
          onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
            setEditedCar((prevDetails) => ({
              ...prevDetails,
              engineCapacity: parseInt(e.target.value),
            }))
          }
          name="engineCapacity"
        />
        <br />
        <label htmlFor="productionDate">Data produkcji</label>
        <input
          type="date"
          id="productionDate"
          value={editedCar.productionDate}
          onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
            setEditedCar((prevDetails) => ({
              ...prevDetails,
              productionDate: e.target.value,
            }))
          }
          name="productionDate"
        />
        <br />
        <label htmlFor="carFuelConsumptions">Spalanie</label>
        <input
          type="number"
          id="carFuelConsumptions"
          value={editedCar.carFuelConsumption}
          onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
            setEditedCar((prevDetails) => ({
              ...prevDetails,
              carFuelConsumption: parseInt(e.target.value),
            }))
          }
          name="carFuelConsumptions"
        />
        <br />
        <label htmlFor="bodyType">Typ nadwozia</label>
        <input
          type="number"
          id="bodyType"
          value={editedCar.bodyType}
          onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
            setEditedCar((prevDetails) => ({
              ...prevDetails,
              bodyType: parseInt(e.target.value),
            }))
          }
          name="bodyType"
        />
        <br />
        <button type="submit">Edytuj</button>
      </form>
    </>
  );
};

export default EditForm;
