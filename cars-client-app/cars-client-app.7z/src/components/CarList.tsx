﻿import React, { useState, useEffect } from "react";
import axios from "axios";

export interface Car {
  id: number;
  brand: string;
  model: string;
  doorsNumber: number;
  luggageCapacity: number;
  engineCapacity: number;
  fuelType: number;
  productionDate: string;
  carFuelConsumption: number;
  bodyType: number;
}

interface CarListProps {
  fetchData: () => void;
  cars: Car[];
  handleEditMode: (id: number) => void;
}

const CarList = (props: CarListProps) => {
  const handleEdit = (id: number) => {
    props.handleEditMode(id);
  };

  useEffect(() => {
    props.fetchData();
  }, []);

  const remove = async (id: any) => {
    await axios
      .delete(`http://localhost:5242/api/Car/${id}`)
      .then((response) => {
        console.log("dziala");
        props.fetchData();
      })
      .catch((error) => {
        console.error(error);
      });
  };

  const update = async (id: any) => {
    await axios
      .put(`http://localhost:5242/api/Car/${id}`, {})
      .then((response) => {
        console.log("dziala");
        props.fetchData();
      })
      .catch((error) => {
        console.error(error);
      });
  };

  return (
    <div>
      <h1>Lista samochodów</h1>
      <ul>
        {props.cars.map((car: Car) => (
          <li key={car.id}>
            <p>
              {`Marka: ${car.brand}, Model: ${car.model}
                        , Drzwi: ${car.doorsNumber},Pojemność bagażu: ${
                car.luggageCapacity
              },
                        Pojemność silnika: ${car.engineCapacity},Spalanie: ${
                car.carFuelConsumption
              },Produkcja:
                         ${car.productionDate.split("T")[0]},Typ paliwa: ${
                car.fuelType
              },Rodzaj: 
                         ${car.bodyType}`}
              {}
            </p>
            <div>
              <button onClick={() => remove(car.id)}>Usuń</button>
              <button onClick={() => handleEdit(car.id)}>Edytuj</button>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default CarList;
